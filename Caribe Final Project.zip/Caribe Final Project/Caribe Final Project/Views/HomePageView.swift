//
//  HomePageView.swift
//  Caribe Final Project
//
//  Created by Luisana Barajas on 11/21/23.
//

import SwiftUI

struct HomePageView: View {
    @EnvironmentObject var cartManager: CartManager
    var body: some View {
        ZStack(alignment: .top) {
            Color.white
                .edgesIgnoringSafeArea(.all)
            ExtractedView()
        }
    }
}

struct HomePageView_Previews: PreviewProvider {
    static var previews: some View {
        HomePageView()
            .environmentObject(CartManager())
    }
}

struct ExtractedView: View {
    @EnvironmentObject var cartManager: CartManager
    var body: some View {
        NavigationStack{
            VStack(alignment: .leading) {
                Image(systemName: "location.north.fill")
                    .resizable()
                    .frame(width: 20, height: 20)
                    .padding(.trailing)
                
                Text("Colombia")
                    .font(.title)
                    .foregroundColor(.gray)
                Spacer()
                NavigationLink(destination: Text("")){
                    CartButton(numberOfProducts: cartManager.products.count)
                }
            }
        }
    }
}
