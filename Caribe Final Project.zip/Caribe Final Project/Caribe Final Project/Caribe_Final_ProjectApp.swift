//
//  Caribe_Final_ProjectApp.swift
//  Caribe Final Project
//
//  Created by Luisana Barajas on 11/20/23.
//

import SwiftUI

@main
struct Caribe_Final_ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
