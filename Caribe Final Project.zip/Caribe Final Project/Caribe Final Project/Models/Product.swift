//
//  Product.swift
//  Caribe Final Project
//
//  Created by Luisana Barajas on 11/21/23.
//

import Foundation

struct Product: Identifiable {
    var id = UUID()
    var name: String
    var image: String
    var description: String
    var supplier: String
    var price: Int

}

var productList = [
Product(
    name: "Cardboard Box",
    image: "pexels-karolina-grabowska-4498135",
    description: "",
    supplier: "Ike",
    price: 5),
Product(
    name: "Textiles",
    image: "pexels-pixabay-276267",
    description: "",
    supplier: "Sara",
    price: 6),
Product(
    name: "Linen",
    image: "AdobeStock_102605067_Preview",
    description: "",
    supplier: "Random",
    price: 8),
Product(
    name: "Oil",
    image: "pexels-karolina-grabowska-4735904",
    description: "",
    supplier: "Suave",
    price: 5),
]
